
from pymavlink import mavutil

connection = mavutil.mavlink_connection("./data.bin")

messages = []

while message := connection.recv_msg():
        messages.append(message)
                                                                                                                                                                         
attitude_messages = list(filter(lambda message: message.get_type() == "ATT", messages))
battery_mssages = list(filter(lambda message: message.get_type() == "BAT", messages))

print(battery_mssages)

